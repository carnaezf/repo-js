// assets/js/main.js

import { saludar } from './modules/saludo.js'

document.addEventListener('DOMContentLoaded', () => {
    const boton = document.getElementById('miBoton')
    boton.addEventListener('click', () => {
        saludar()
    })
})
