// assets/js/modules/saludo.js

export function saludar() {
    alert("¡Hola desde un módulo JS!");
    console.log('Saludo desde el modulo Saludo');
    
}
